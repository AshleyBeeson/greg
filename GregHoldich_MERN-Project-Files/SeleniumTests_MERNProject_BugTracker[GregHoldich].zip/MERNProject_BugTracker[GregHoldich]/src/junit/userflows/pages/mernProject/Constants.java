package junit.userflows.pages.mernProject;

public class Constants {

	private static final String baseUrl = "http://localhost:8080/";

	public static String getBaseUrl() {
		return baseUrl;
	}
	
}
